function Error() {
    return <h1>Error Page Or Not Found 404</h1>;
}

export default Error;
