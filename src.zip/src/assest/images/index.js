const images = {
    logoBlack: require('../../assest/images/logo-black.png'),
    logoWhite: require('../../assest/images/logo-white.png'),
    noImage: require('./no-image.jpg'),
};

export default images;
