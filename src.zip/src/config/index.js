import routes from './routes';
import apikey from './apikeys';
const config = {
    routes,
    apikey,
};

export default config;
