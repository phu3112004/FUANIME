const CLIENT_ID = '35440320986-sapqgsokicnd8jlncenkllbctchiemtd.apps.googleusercontent.com';

const apikey = {
    API_KEY: 'AIzaSyCKT1v48V0DkxQ1VJU9GvwjUhOga4ikMsE',
    CHANNEL_ID: 'UCkgdDBHO7zl3tWIjldQeK7g',
    GET_LINK_TOKEN: `https://accounts.google.com/o/oauth2/v2/auth?scope=https://www.googleapis.com/auth/userinfo.email%20https://www.googleapis.com/auth/userinfo.profile&response_type=token&redirect_uri=http://localhost:3000/&client_id=${CLIENT_ID}`,
};

export default apikey;
//secret
//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
